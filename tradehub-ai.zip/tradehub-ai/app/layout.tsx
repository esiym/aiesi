import type { Metadata } from "next";
import { Fraunces, Inter, JetBrains_Mono } from "next/font/google";
import "./globals.css";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

const fraunces = Fraunces({
  subsets: ["latin"],
  variable: "--font-fraunces",
  weight: ["400", "500", "600"],
  style: ["normal", "italic"],
  display: "swap",
});

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  weight: ["400", "500", "600", "700"],
  display: "swap",
});

const mono = JetBrains_Mono({
  subsets: ["latin"],
  variable: "--font-mono",
  weight: ["400", "500"],
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL("https://tradehub-ai.com"),
  title: {
    default: "TradeHub AI — Trade Smarter With AI",
    template: "%s | TradeHub AI",
  },
  description:
    "AI-powered trading tools for modern traders. Chart analysis, risk calculation, trade journaling, and backtesting in one premium platform.",
  keywords: [
    "AI trading",
    "trading platform",
    "chart analysis",
    "risk calculator",
    "trade journal",
    "backtesting",
    "TradeHub AI",
  ],
  openGraph: {
    title: "TradeHub AI — Trade Smarter With AI",
    description: "AI-powered trading tools for modern traders.",
    url: "https://tradehub-ai.com",
    siteName: "TradeHub AI",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "TradeHub AI — Trade Smarter With AI",
    description: "AI-powered trading tools for modern traders.",
  },
  robots: {
    index: true,
    follow: true,
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={`${fraunces.variable} ${inter.variable} ${mono.variable}`}>
      <body className="font-body bg-ink-900 text-bone antialiased">
        <Navbar />
        <main>{children}</main>
        <Footer />
      </body>
    </html>
  );
}

import Hero from "@/components/Hero";
import TickerTape from "@/components/TickerTape";
import FeatureGrid from "@/components/FeatureGrid";
import Founder from "@/components/Founder";
import PricingGrid from "@/components/PricingGrid";
import SectionHeading from "@/components/SectionHeading";
import CTASection from "@/components/CTASection";

export default function HomePage() {
  return (
    <>
      <Hero />
      <TickerTape />

      <section className="py-24 lg:py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-10">
          <SectionHeading
            eyebrow="Inside the platform"
            title="Everything a serious trader needs, in one place"
            description="Six tools built to remove guesswork from every stage of the trade — from idea to execution to review."
          />
          <div className="mt-14">
            <FeatureGrid />
          </div>
        </div>
      </section>

      <Founder />

      <section className="py-24 lg:py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-10">
          <SectionHeading
            eyebrow="Pricing"
            title="Simple plans that scale with your edge"
            description="Start free. Upgrade the moment your strategy earns it."
          />
          <div className="mt-14">
            <PricingGrid />
          </div>
        </div>
      </section>

      <CTASection />
    </>
  );
}

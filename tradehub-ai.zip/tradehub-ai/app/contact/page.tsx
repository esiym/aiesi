import type { Metadata } from "next";
import SectionHeading from "@/components/SectionHeading";
import ContactForm from "@/components/ContactForm";
import { Mail, MessageCircle, MapPin } from "lucide-react";

export const metadata: Metadata = {
  title: "Contact",
  description: "Get in touch with the TradeHub AI team.",
};

const info = [
  { icon: Mail, label: "Email", value: "hello@tradehub-ai.com" },
  { icon: MessageCircle, label: "Live chat", value: "Available 9am–6pm ET" },
  { icon: MapPin, label: "Office", value: "New York, NY" },
];

export default function ContactPage() {
  return (
    <section className="py-20 lg:py-28">
      <div className="mx-auto max-w-6xl px-6 lg:px-10">
        <SectionHeading
          eyebrow="Contact"
          title="We'd love to hear from you"
          description="Questions about pricing, features, or partnerships — reach out and we'll respond within one business day."
        />

        <div className="mt-16 grid grid-cols-1 gap-10 lg:grid-cols-5">
          <div className="lg:col-span-2 space-y-4">
            {info.map((item) => (
              <div key={item.label} className="glass flex items-center gap-4 rounded-2xl p-5">
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-gold/30 bg-gold/5">
                  <item.icon className="h-5 w-5 text-gold" strokeWidth={1.75} />
                </span>
                <div>
                  <p className="text-xs text-bone-dim">{item.label}</p>
                  <p className="text-sm">{item.value}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="lg:col-span-3">
            <ContactForm />
          </div>
        </div>
      </div>
    </section>
  );
}

import type { Metadata } from "next";
import Link from "next/link";
import SectionHeading from "@/components/SectionHeading";
import GlassCard from "@/components/GlassCard";
import { ArrowUpRight } from "lucide-react";

export const metadata: Metadata = {
  title: "Blog",
  description:
    "Insights on AI-driven trading, risk management, and building a consistently profitable strategy.",
};

const posts = [
  {
    slug: "why-most-traders-lose-money",
    title: "Why most traders lose money — and how AI changes the math",
    excerpt:
      "The edge isn't a secret indicator. It's consistency, and consistency is exactly what AI is good at enforcing.",
    tag: "Strategy",
    date: "Jul 12, 2026",
  },
  {
    slug: "risk-first-trading",
    title: "Risk-first trading: sizing positions before picking direction",
    excerpt:
      "Professional traders decide how much they can lose before they decide what to buy. Here's how to build that habit.",
    tag: "Risk",
    date: "Jun 28, 2026",
  },
  {
    slug: "backtesting-mistakes",
    title: "Five backtesting mistakes that make bad strategies look great",
    excerpt:
      "Overfitting, survivorship bias, and lookahead bias quietly inflate backtest results. Here's how to catch them.",
    tag: "Backtesting",
    date: "Jun 09, 2026",
  },
  {
    slug: "reading-the-calendar",
    title: "Reading the economic calendar like a desk trader",
    excerpt:
      "Not all red-flagged events matter equally. A framework for filtering noise from genuine volatility risk.",
    tag: "Macro",
    date: "May 22, 2026",
  },
];

export default function BlogPage() {
  return (
    <section className="py-20 lg:py-28">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <SectionHeading
          eyebrow="Blog"
          title="Notes on trading with discipline"
          description="Short, practical writing on strategy, risk, and the psychology of consistent execution."
        />

        <div className="mt-14 grid grid-cols-1 gap-6 md:grid-cols-2">
          {posts.map((post, i) => (
            <GlassCard key={post.slug} delay={i * 0.06} className="flex flex-col">
              <div className="flex items-center gap-3 text-xs text-bone-dim">
                <span className="rounded-full border border-gold/30 px-2.5 py-1 text-gold">
                  {post.tag}
                </span>
                <span>{post.date}</span>
              </div>
              <h3 className="mt-4 font-display text-2xl leading-snug">
                {post.title}
              </h3>
              <p className="mt-3 flex-1 text-sm leading-relaxed text-bone-dim">
                {post.excerpt}
              </p>
              <Link
                href={`/blog/${post.slug}`}
                className="group mt-6 inline-flex items-center gap-1.5 text-sm font-medium text-gold"
              >
                Read article
                <ArrowUpRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </Link>
            </GlassCard>
          ))}
        </div>
      </div>
    </section>
  );
}

import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft } from "lucide-react";

const posts: Record<
  string,
  { title: string; date: string; tag: string; body: string[] }
> = {
  "why-most-traders-lose-money": {
    title: "Why most traders lose money — and how AI changes the math",
    date: "Jul 12, 2026",
    tag: "Strategy",
    body: [
      "Most losing traders don't lack a good setup. They lack a repeatable process for taking the same setup the same way, every time, regardless of how the last trade felt.",
      "AI tools don't remove the need for judgment — they remove the variance in how that judgment gets applied. A chart pattern flagged by a model looks the same at 9am and at 9pm, win streak or losing streak.",
      "The traders who benefit most from AI aren't looking for a signal to blindly follow. They're using it as a second, unemotional opinion before every trade.",
    ],
  },
  "risk-first-trading": {
    title: "Risk-first trading: sizing positions before picking direction",
    date: "Jun 28, 2026",
    tag: "Risk",
    body: [
      "Ask a struggling trader how much they stand to lose on a trade and you'll often get a shrug. Ask a professional and you'll get an exact number, decided before the entry.",
      "Position sizing isn't a detail to figure out after you like a setup. It's the first calculation, because it's the only variable you fully control.",
      "A risk calculator that runs before every entry turns this from a discipline you have to remember into a step you can't skip.",
    ],
  },
  "backtesting-mistakes": {
    title: "Five backtesting mistakes that make bad strategies look great",
    date: "Jun 09, 2026",
    tag: "Backtesting",
    body: [
      "A backtest that looks too good usually is. The most common culprit is lookahead bias — using information in the test that wouldn't have been available in real time.",
      "Overfitting is the second trap: tuning a strategy's parameters until it fits historical noise instead of a real, repeatable edge.",
      "Good backtesting tools flag both automatically, so the strategy that reaches your live account has actually earned its confidence.",
    ],
  },
  "reading-the-calendar": {
    title: "Reading the economic calendar like a desk trader",
    date: "May 22, 2026",
    tag: "Macro",
    body: [
      "Not every red-flagged event moves every instrument. A rate decision matters enormously for currency pairs and much less for a mid-cap equity.",
      "Desk traders filter the calendar down to the two or three events that actually intersect with what they trade, and treat the rest as background noise.",
      "An economic calendar that ranks events by relevance to your watchlist — not just by generic 'impact' — saves the filtering work every morning.",
    ],
  },
};

export function generateStaticParams() {
  return Object.keys(posts).map((slug) => ({ slug }));
}

export function generateMetadata({
  params,
}: {
  params: { slug: string };
}): Metadata {
  const post = posts[params.slug];
  if (!post) return { title: "Post not found" };
  return {
    title: post.title,
    description: post.body[0],
  };
}

export default function BlogPostPage({ params }: { params: { slug: string } }) {
  const post = posts[params.slug];
  if (!post) notFound();

  return (
    <article className="py-20 lg:py-28">
      <div className="mx-auto max-w-2xl px-6 lg:px-10">
        <Link
          href="/blog"
          className="inline-flex items-center gap-1.5 text-sm text-bone-dim hover:text-gold"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          Back to blog
        </Link>

        <div className="mt-8 flex items-center gap-3 text-xs text-bone-dim">
          <span className="rounded-full border border-gold/30 px-2.5 py-1 text-gold">
            {post.tag}
          </span>
          <span>{post.date}</span>
        </div>

        <h1 className="mt-4 font-display text-3xl leading-tight sm:text-4xl">
          {post.title}
        </h1>

        <div className="mt-8 space-y-5 text-base leading-relaxed text-bone-dim">
          {post.body.map((p, i) => (
            <p key={i}>{p}</p>
          ))}
        </div>
      </div>
    </article>
  );
}

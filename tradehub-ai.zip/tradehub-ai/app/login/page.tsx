import type { Metadata } from "next";
import AuthForm from "@/components/AuthForm";

export const metadata: Metadata = {
  title: "Log in",
  description: "Log in to your TradeHub AI account.",
};

export default function LoginPage() {
  return <AuthForm mode="login" />;
}

import type { Metadata } from "next";
import FeatureGrid from "@/components/FeatureGrid";
import SectionHeading from "@/components/SectionHeading";
import CTASection from "@/components/CTASection";

export const metadata: Metadata = {
  title: "Features",
  description:
    "Explore TradeHub AI's full toolkit: AI chart analysis, risk calculator, trade journal, economic calendar, performance analytics, and backtesting.",
};

export default function FeaturesPage() {
  return (
    <>
      <section className="pb-8 pt-20 lg:pt-28">
        <div className="mx-auto max-w-7xl px-6 lg:px-10">
          <SectionHeading
            eyebrow="Features"
            title="A complete toolkit for disciplined traders"
            description="Every feature below was built to answer one question: is this trade worth taking? TradeHub AI helps you answer it faster and with more evidence."
          />
        </div>
      </section>

      <section className="py-16 lg:py-24">
        <div className="mx-auto max-w-7xl px-6 lg:px-10">
          <FeatureGrid />
        </div>
      </section>

      <CTASection />
    </>
  );
}

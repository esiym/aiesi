import type { Metadata } from "next";
import AuthForm from "@/components/AuthForm";

export const metadata: Metadata = {
  title: "Sign up",
  description: "Create your free TradeHub AI account.",
};

export default function SignupPage() {
  return <AuthForm mode="signup" />;
}

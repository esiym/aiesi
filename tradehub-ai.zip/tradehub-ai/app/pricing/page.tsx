import type { Metadata } from "next";
import PricingGrid from "@/components/PricingGrid";
import SectionHeading from "@/components/SectionHeading";
import FAQ from "@/components/FAQ";

export const metadata: Metadata = {
  title: "Pricing",
  description:
    "Simple, transparent pricing for TradeHub AI. Free, Pro at $19/month, and Elite at $49/month.",
};

export default function PricingPage() {
  return (
    <>
      <section className="pb-8 pt-20 lg:pt-28">
        <div className="mx-auto max-w-7xl px-6 lg:px-10">
          <SectionHeading
            eyebrow="Pricing"
            title="Plans built around how you trade"
            description="No hidden fees. Cancel anytime. Every paid plan includes a 14-day money-back guarantee."
          />
        </div>
      </section>

      <section className="py-16 lg:py-24">
        <div className="mx-auto max-w-7xl px-6 lg:px-10">
          <PricingGrid />
        </div>
      </section>

      <section className="border-t border-white/[0.06] py-24 lg:py-32">
        <div className="mx-auto max-w-3xl px-6 lg:px-10">
          <SectionHeading
            eyebrow="Questions"
            title="Frequently asked questions"
          />
          <div className="mt-14">
            <FAQ />
          </div>
        </div>
      </section>
    </>
  );
}

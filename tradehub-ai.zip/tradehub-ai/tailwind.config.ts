import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        ink: {
          DEFAULT: "#050505",
          900: "#0a0a0a",
          800: "#121212",
          700: "#1a1a1a",
          600: "#242424",
        },
        bone: {
          DEFAULT: "#f4f2ec",
          dim: "#c9c6bc",
        },
        gold: {
          DEFAULT: "#c9a227",
          light: "#e8cc6e",
          dim: "#8a7020",
          hair: "rgba(201,162,39,0.35)",
        },
      },
      fontFamily: {
        display: ["var(--font-fraunces)", "serif"],
        body: ["var(--font-inter)", "sans-serif"],
        mono: ["var(--font-mono)", "monospace"],
      },
      backgroundImage: {
        "gold-gradient": "linear-gradient(135deg, #e8cc6e 0%, #c9a227 45%, #8a7020 100%)",
        "grain": "url('/grain.png')",
      },
      boxShadow: {
        "gold-glow": "0 0 40px -10px rgba(201,162,39,0.35)",
        "card": "0 8px 30px rgba(0,0,0,0.45)",
      },
      keyframes: {
        ticker: {
          "0%": { transform: "translateX(0)" },
          "100%": { transform: "translateX(-50%)" },
        },
      },
      animation: {
        ticker: "ticker 30s linear infinite",
      },
    },
  },
  plugins: [],
};
export default config;

import Stripe from "stripe";

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: "2024-11-20.acacia",
  typescript: true,
});

// Map plan names to the Price IDs created in your Stripe dashboard.
export const STRIPE_PRICE_IDS: Record<"pro" | "elite", string> = {
  pro: process.env.STRIPE_PRICE_ID_PRO!,
  elite: process.env.STRIPE_PRICE_ID_ELITE!,
};

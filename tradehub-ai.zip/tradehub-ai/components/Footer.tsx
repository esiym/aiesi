import Link from "next/link";
import { LineChart, Twitter, Linkedin, Github } from "lucide-react";

export default function Footer() {
  return (
    <footer className="hairline border-t bg-ink-900">
      <div className="mx-auto max-w-7xl px-6 py-16 lg:px-10">
        <div className="grid grid-cols-2 gap-10 md:grid-cols-4">
          <div className="col-span-2">
            <Link href="/" className="flex items-center gap-2.5">
              <span className="flex h-8 w-8 items-center justify-center rounded-full border border-gold/40 bg-gold/5">
                <LineChart className="h-4 w-4 text-gold" strokeWidth={1.75} />
              </span>
              <span className="font-display text-lg">
                TradeHub <span className="text-gradient-gold italic">AI</span>
              </span>
            </Link>
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-bone-dim">
              AI-powered trading tools for modern traders who demand precision
              over noise.
            </p>
            <div className="mt-6 flex gap-4">
              {[Twitter, Linkedin, Github].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  aria-label="social link"
                  className="flex h-9 w-9 items-center justify-center rounded-full hairline text-bone-dim transition-colors hover:border-gold/40 hover:text-gold"
                >
                  <Icon className="h-4 w-4" strokeWidth={1.75} />
                </a>
              ))}
            </div>
          </div>

          <div>
            <p className="eyebrow text-xs uppercase text-gold/70">Product</p>
            <ul className="mt-4 space-y-3 text-sm text-bone-dim">
              <li><Link href="/features" className="hover:text-gold">Features</Link></li>
              <li><Link href="/pricing" className="hover:text-gold">Pricing</Link></li>
              <li><Link href="/dashboard" className="hover:text-gold">Dashboard</Link></li>
            </ul>
          </div>

          <div>
            <p className="eyebrow text-xs uppercase text-gold/70">Company</p>
            <ul className="mt-4 space-y-3 text-sm text-bone-dim">
              <li><Link href="/blog" className="hover:text-gold">Blog</Link></li>
              <li><Link href="/contact" className="hover:text-gold">Contact</Link></li>
              <li><Link href="/#founder" className="hover:text-gold">Founder</Link></li>
            </ul>
          </div>
        </div>

        <div className="mt-14 flex flex-col items-center justify-between gap-4 border-t border-white/[0.06] pt-8 text-xs text-bone-dim md:flex-row">
          <p>© {new Date().getFullYear()} TradeHub AI. All rights reserved.</p>
          <p className="text-bone-dim/70">
            Trading involves risk. Past performance does not guarantee future results.
          </p>
        </div>
      </div>
    </footer>
  );
}

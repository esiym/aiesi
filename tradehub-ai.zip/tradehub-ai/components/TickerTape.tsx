const tickers = [
  { symbol: "BTC/USD", change: "+2.41%", up: true },
  { symbol: "ETH/USD", change: "+1.08%", up: true },
  { symbol: "NAS100", change: "-0.34%", up: false },
  { symbol: "SPX500", change: "+0.62%", up: true },
  { symbol: "XAU/USD", change: "+0.19%", up: true },
  { symbol: "EUR/USD", change: "-0.11%", up: false },
  { symbol: "AAPL", change: "+0.87%", up: true },
  { symbol: "TSLA", change: "-1.22%", up: false },
];

function Row() {
  return (
    <div className="flex shrink-0 items-center gap-10 pr-10">
      {tickers.map((t) => (
        <div key={t.symbol} className="flex items-center gap-2 font-mono text-xs tracking-wide">
          <span className="text-bone-dim">{t.symbol}</span>
          <span className={t.up ? "text-gold" : "text-bone-dim/50"}>{t.change}</span>
        </div>
      ))}
    </div>
  );
}

export default function TickerTape() {
  return (
    <div className="hairline overflow-hidden border-y bg-ink-900/60 py-3">
      <div className="flex w-max animate-ticker">
        <Row />
        <Row />
      </div>
    </div>
  );
}

"use client";

import { motion } from "framer-motion";
import { clsx } from "clsx";
import { ReactNode } from "react";

export default function GlassCard({
  children,
  className,
  gold = false,
  delay = 0,
}: {
  children: ReactNode;
  className?: string;
  gold?: boolean;
  delay?: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.6, delay, ease: [0.22, 1, 0.36, 1] }}
      whileHover={{ y: -6 }}
      className={clsx(
        "rounded-2xl p-6 shadow-card transition-shadow duration-300 hover:shadow-gold-glow",
        gold ? "glass-gold" : "glass",
        className
      )}
    >
      {children}
    </motion.div>
  );
}

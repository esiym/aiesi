"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Plus } from "lucide-react";

const faqs = [
  {
    q: "Can I cancel my subscription anytime?",
    a: "Yes. Cancel from your dashboard at any time — you'll keep access until the end of your billing period, no questions asked.",
  },
  {
    q: "Does the Free plan expire?",
    a: "No. The Free plan is free forever, with daily limits on AI chart analysis and journal entries. Upgrade whenever you need more.",
  },
  {
    q: "What markets does TradeHub AI support?",
    a: "Forex, crypto, indices, and equities. Any instrument with public price data can be analyzed, journaled, and backtested.",
  },
  {
    q: "Is my trading data secure?",
    a: "Yes. All data is encrypted in transit and at rest, and stored in isolated, access-controlled Supabase projects.",
  },
];

export default function FAQ() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <div className="divide-y divide-white/[0.06] hairline rounded-2xl">
      {faqs.map((item, i) => (
        <div key={item.q} className="px-6">
          <button
            onClick={() => setOpen(open === i ? null : i)}
            className="flex w-full items-center justify-between gap-4 py-5 text-left"
          >
            <span className="font-display text-lg">{item.q}</span>
            <motion.span
              animate={{ rotate: open === i ? 45 : 0 }}
              transition={{ duration: 0.2 }}
              className="shrink-0 text-gold"
            >
              <Plus className="h-5 w-5" />
            </motion.span>
          </button>
          <AnimatePresence initial={false}>
            {open === i && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.25, ease: "easeInOut" }}
                className="overflow-hidden"
              >
                <p className="pb-5 text-sm leading-relaxed text-bone-dim">
                  {item.a}
                </p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      ))}
    </div>
  );
}

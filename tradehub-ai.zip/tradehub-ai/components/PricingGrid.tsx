"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { clsx } from "clsx";
import { Check } from "lucide-react";

export const plans = [
  {
    name: "Free",
    price: "$0",
    period: "forever",
    description: "For traders exploring what AI can do for their edge.",
    features: [
      "AI Chart Analysis (5/day)",
      "Basic Risk Calculator",
      "Trade Journal — 25 entries",
      "Economic Calendar",
    ],
    cta: "Start Free",
    featured: false,
  },
  {
    name: "Pro",
    price: "$19",
    period: "/month",
    description: "For active traders who want full visibility on every trade.",
    features: [
      "Unlimited AI Chart Analysis",
      "Advanced Risk Calculator",
      "Unlimited Trade Journal",
      "Performance Analytics",
      "Priority support",
    ],
    cta: "Start Pro",
    featured: true,
  },
  {
    name: "Elite",
    price: "$49",
    period: "/month",
    description: "For professionals who backtest before they risk a dollar.",
    features: [
      "Everything in Pro",
      "Unlimited Backtesting",
      "Multi-strategy analytics",
      "API access",
      "1:1 onboarding session",
    ],
    cta: "Start Elite",
    featured: false,
  },
];

export default function PricingGrid() {
  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
      {plans.map((plan, i) => (
        <motion.div
          key={plan.name}
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.6, delay: i * 0.1, ease: [0.22, 1, 0.36, 1] }}
          whileHover={{ y: -6 }}
          className={clsx(
            "relative flex flex-col rounded-2xl p-8 shadow-card transition-shadow duration-300 hover:shadow-gold-glow",
            plan.featured ? "glass-gold lg:scale-105" : "glass"
          )}
        >
          {plan.featured && (
            <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-gold-gradient px-4 py-1 text-[11px] font-medium uppercase tracking-wide text-ink-900">
              Most Popular
            </span>
          )}
          <h3 className="font-display text-2xl">{plan.name}</h3>
          <p className="mt-2 text-sm text-bone-dim">{plan.description}</p>
          <div className="mt-6 flex items-baseline gap-1">
            <span className="font-display text-4xl">{plan.price}</span>
            <span className="text-sm text-bone-dim">{plan.period}</span>
          </div>

          <ul className="mt-8 flex-1 space-y-3">
            {plan.features.map((f) => (
              <li key={f} className="flex items-start gap-2.5 text-sm text-bone-dim">
                <Check className="mt-0.5 h-4 w-4 shrink-0 text-gold" strokeWidth={2} />
                {f}
              </li>
            ))}
          </ul>

          <Link
            href="/signup"
            className={clsx(
              "mt-8 rounded-full px-6 py-3 text-center text-sm font-medium transition-transform hover:scale-[1.02]",
              plan.featured
                ? "bg-gold-gradient text-ink-900 shadow-gold-glow"
                : "hairline text-bone hover:border-gold/40 hover:text-gold"
            )}
          >
            {plan.cta}
          </Link>
        </motion.div>
      ))}
    </div>
  );
}

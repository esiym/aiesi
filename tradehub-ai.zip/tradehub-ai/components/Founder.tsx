"use client";

import { motion } from "framer-motion";

export default function Founder() {
  return (
    <section id="founder" className="relative border-t border-white/[0.06] py-24 lg:py-32">
      <div className="mx-auto grid max-w-6xl grid-cols-1 items-center gap-14 px-6 lg:grid-cols-2 lg:px-10">
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
          className="relative mx-auto w-full max-w-sm"
        >
          <motion.div
            whileHover={{ y: -8, rotate: -1 }}
            transition={{ type: "spring", stiffness: 200, damping: 16 }}
            className="glass relative aspect-[4/5] overflow-hidden rounded-3xl shadow-card"
          >
            {/*
              Replace the placeholder below with the uploaded founder photo.
              Drop the image into /public (e.g. /public/founder.jpg) and swap
              the src prop accordingly:

              <Image src="/founder.jpg" alt="Founder of TradeHub AI" fill className="object-cover" />
            */}
            <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-ink-700 to-ink-900">
              <span className="font-display text-6xl text-gold/30">TH</span>
            </div>
            <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-ink-900/70 via-transparent to-transparent" />
          </motion.div>
          <div
            aria-hidden
            className="absolute -bottom-4 -right-4 -z-10 h-full w-full rounded-3xl border border-gold/25"
          />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.7, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
        >
          <p className="eyebrow text-xs uppercase text-gold/80">Founder</p>
          <h2 className="mt-4 font-display text-3xl leading-tight sm:text-4xl">
            Built by a trader,
            <br />
            <span className="text-gradient-gold italic">for traders.</span>
          </h2>
          <p className="mt-6 max-w-md text-base leading-relaxed text-bone-dim">
            &ldquo;My mission is helping traders become consistently profitable
            through AI tools.&rdquo;
          </p>
          <div className="mt-8 flex items-center gap-4">
            <div className="h-px w-10 bg-gold/50" />
            <div>
              <p className="font-display text-lg">Alex Morgan</p>
              <p className="text-sm text-bone-dim">Founder &amp; CEO, TradeHub AI</p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Loader2, CheckCircle2 } from "lucide-react";
import { createClient } from "@/lib/supabase/client";

export default function ContactForm() {
  const supabase = createClient();
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const { error } = await supabase.from("contact_messages").insert({
      name: form.name,
      email: form.email,
      message: form.message,
    });

    setLoading(false);

    if (error) {
      setError("Something went wrong. Please try again.");
      return;
    }

    setSent(true);
  }

  if (sent) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
        className="glass flex h-full min-h-[320px] flex-col items-center justify-center rounded-2xl p-10 text-center"
      >
        <CheckCircle2 className="h-10 w-10 text-gold" strokeWidth={1.5} />
        <h3 className="mt-4 font-display text-xl">Message sent</h3>
        <p className="mt-2 text-sm text-bone-dim">
          Thanks for reaching out — we'll reply within one business day.
        </p>
      </motion.div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="glass space-y-4 rounded-2xl p-8">
      <div>
        <label htmlFor="name" className="text-xs text-bone-dim">
          Name
        </label>
        <input
          id="name"
          required
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
          placeholder="Jane Trader"
          className="mt-1.5 w-full rounded-lg hairline bg-ink-800 px-4 py-3 text-sm text-bone outline-none transition-colors focus:border-gold/50"
        />
      </div>

      <div>
        <label htmlFor="email" className="text-xs text-bone-dim">
          Email
        </label>
        <input
          id="email"
          type="email"
          required
          value={form.email}
          onChange={(e) => setForm({ ...form, email: e.target.value })}
          placeholder="you@example.com"
          className="mt-1.5 w-full rounded-lg hairline bg-ink-800 px-4 py-3 text-sm text-bone outline-none transition-colors focus:border-gold/50"
        />
      </div>

      <div>
        <label htmlFor="message" className="text-xs text-bone-dim">
          Message
        </label>
        <textarea
          id="message"
          required
          rows={5}
          value={form.message}
          onChange={(e) => setForm({ ...form, message: e.target.value })}
          placeholder="How can we help?"
          className="mt-1.5 w-full resize-none rounded-lg hairline bg-ink-800 px-4 py-3 text-sm text-bone outline-none transition-colors focus:border-gold/50"
        />
      </div>

      {error && (
        <p className="rounded-lg border border-red-500/30 bg-red-500/10 px-4 py-2.5 text-xs text-red-300">
          {error}
        </p>
      )}

      <button
        type="submit"
        disabled={loading}
        className="flex w-full items-center justify-center gap-2 rounded-full bg-gold-gradient px-6 py-3 text-sm font-medium text-ink-900 shadow-gold-glow transition-transform hover:scale-[1.01] disabled:opacity-60 sm:w-auto"
      >
        {loading && <Loader2 className="h-4 w-4 animate-spin" />}
        Send message
      </button>
    </form>
  );
}

"use client";

import GlassCard from "./GlassCard";
import {
  LineChart, Calculator, BookOpen, CalendarClock, BarChart3, History,
} from "lucide-react";

export const features = [
  {
    icon: LineChart,
    title: "AI Chart Analysis",
    description:
      "Point at any chart and get instant pattern recognition, support and resistance zones, and trend confidence scores.",
  },
  {
    icon: Calculator,
    title: "Risk Calculator",
    description:
      "Size every position with precision. Set your risk tolerance once and let it calculate lot size and stop distance automatically.",
  },
  {
    icon: BookOpen,
    title: "Trade Journal",
    description:
      "Log entries, exits, and reasoning in seconds. AI tags each trade with the behavioral pattern behind it.",
  },
  {
    icon: CalendarClock,
    title: "Economic Calendar",
    description:
      "Track high-impact events across every major market, ranked by expected volatility for your watchlist.",
  },
  {
    icon: BarChart3,
    title: "Performance Analytics",
    description:
      "See win rate, expectancy, and drawdown broken down by strategy, session, and instrument — updated in real time.",
  },
  {
    icon: History,
    title: "Backtesting",
    description:
      "Run any strategy against a decade of historical data and get a full report before you risk a single dollar live.",
  },
];

export default function FeatureGrid() {
  return (
    <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
      {features.map((f, i) => (
        <GlassCard key={f.title} delay={i * 0.08}>
          <span className="flex h-11 w-11 items-center justify-center rounded-xl border border-gold/30 bg-gold/5">
            <f.icon className="h-5 w-5 text-gold" strokeWidth={1.75} />
          </span>
          <h3 className="mt-5 font-display text-xl">{f.title}</h3>
          <p className="mt-2.5 text-sm leading-relaxed text-bone-dim">
            {f.description}
          </p>
        </GlassCard>
      ))}
    </div>
  );
}

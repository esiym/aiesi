"use client";

import { motion } from "framer-motion";
import Link from "next/link";
import {
  LineChart, Calculator, BookOpen, CalendarClock, BarChart3, History,
  LayoutGrid, Settings, LogOut, TrendingUp, TrendingDown, Wallet,
} from "lucide-react";
import GlassCard from "./GlassCard";

const modules = [
  {
    icon: LineChart,
    title: "AI Chart Analysis",
    description: "3 new pattern signals detected on your watchlist.",
    meta: "Updated 2m ago",
  },
  {
    icon: Calculator,
    title: "Risk Calculator",
    description: "Current default risk: 1.5% per trade.",
    meta: "12 calculations this week",
  },
  {
    icon: BookOpen,
    title: "Trade Journal",
    description: "4 trades logged today, 2 awaiting your notes.",
    meta: "58 entries total",
  },
  {
    icon: CalendarClock,
    title: "Economic Calendar",
    description: "FOMC statement in 3 hours — high impact on your pairs.",
    meta: "6 events today",
  },
  {
    icon: BarChart3,
    title: "Performance Analytics",
    description: "Win rate up 4.2% over the trailing 30 days.",
    meta: "Expectancy: +0.38R",
  },
  {
    icon: History,
    title: "Backtesting",
    description: "Your last strategy test completed with a 1.9 profit factor.",
    meta: "3 strategies saved",
  },
];

const stats = [
  { label: "Account Balance", value: "$24,380", change: "+3.2%", up: true, icon: Wallet },
  { label: "Win Rate", value: "61.4%", change: "+4.2%", up: true, icon: TrendingUp },
  { label: "Open Positions", value: "3", change: "-1", up: false, icon: LayoutGrid },
  { label: "Avg. Drawdown", value: "6.1%", change: "-0.8%", up: true, icon: TrendingDown },
];

export default function DashboardShell() {
  return (
    <div className="mx-auto flex max-w-[1600px] flex-col lg:flex-row">
      {/* Sidebar */}
      <aside className="hairline shrink-0 border-b bg-ink-900 px-6 py-6 lg:w-64 lg:border-b-0 lg:border-r lg:px-5">
        <div className="flex items-center gap-2.5">
          <span className="flex h-8 w-8 items-center justify-center rounded-full border border-gold/40 bg-gold/5">
            <LineChart className="h-4 w-4 text-gold" strokeWidth={1.75} />
          </span>
          <span className="font-display text-lg">
            TradeHub <span className="text-gradient-gold italic">AI</span>
          </span>
        </div>

        <nav className="mt-10 hidden flex-col gap-1 lg:flex">
          {[
            { icon: LayoutGrid, label: "Overview", active: true },
            { icon: LineChart, label: "Chart Analysis" },
            { icon: Calculator, label: "Risk Calculator" },
            { icon: BookOpen, label: "Trade Journal" },
            { icon: CalendarClock, label: "Calendar" },
            { icon: BarChart3, label: "Analytics" },
            { icon: History, label: "Backtesting" },
          ].map((item) => (
            <button
              key={item.label}
              className={`flex items-center gap-3 rounded-lg px-3.5 py-2.5 text-sm transition-colors ${
                item.active
                  ? "bg-gold/10 text-gold"
                  : "text-bone-dim hover:bg-white/[0.04] hover:text-bone"
              }`}
            >
              <item.icon className="h-4 w-4" strokeWidth={1.75} />
              {item.label}
            </button>
          ))}
        </nav>

        <div className="mt-10 hidden flex-col gap-1 border-t border-white/[0.06] pt-4 lg:flex">
          <button className="flex items-center gap-3 rounded-lg px-3.5 py-2.5 text-sm text-bone-dim transition-colors hover:bg-white/[0.04] hover:text-bone">
            <Settings className="h-4 w-4" strokeWidth={1.75} />
            Settings
          </button>
          <Link
            href="/"
            className="flex items-center gap-3 rounded-lg px-3.5 py-2.5 text-sm text-bone-dim transition-colors hover:bg-white/[0.04] hover:text-bone"
          >
            <LogOut className="h-4 w-4" strokeWidth={1.75} />
            Log out
          </Link>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 px-6 py-8 lg:px-10 lg:py-10">
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <p className="eyebrow text-xs uppercase text-gold/70">Overview</p>
          <h1 className="mt-2 font-display text-3xl">Welcome back, Alex</h1>
          <p className="mt-1 text-sm text-bone-dim">
            Here's what's happening across your trading tools today.
          </p>
        </motion.div>

        {/* Stats */}
        <div className="mt-8 grid grid-cols-2 gap-4 lg:grid-cols-4">
          {stats.map((s, i) => (
            <motion.div
              key={s.label}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: i * 0.06 }}
              className="glass rounded-2xl p-5"
            >
              <div className="flex items-center justify-between">
                <span className="flex h-9 w-9 items-center justify-center rounded-lg border border-gold/30 bg-gold/5">
                  <s.icon className="h-4 w-4 text-gold" strokeWidth={1.75} />
                </span>
                <span className={`text-xs font-medium ${s.up ? "text-gold" : "text-bone-dim"}`}>
                  {s.change}
                </span>
              </div>
              <p className="mt-4 font-display text-2xl">{s.value}</p>
              <p className="mt-1 text-xs text-bone-dim">{s.label}</p>
            </motion.div>
          ))}
        </div>

        {/* Modules */}
        <div className="mt-10 grid grid-cols-1 gap-5 sm:grid-cols-2 xl:grid-cols-3">
          {modules.map((m, i) => (
            <GlassCard key={m.title} delay={i * 0.06}>
              <div className="flex items-start justify-between">
                <span className="flex h-11 w-11 items-center justify-center rounded-xl border border-gold/30 bg-gold/5">
                  <m.icon className="h-5 w-5 text-gold" strokeWidth={1.75} />
                </span>
                <span className="text-[11px] text-bone-dim/70">{m.meta}</span>
              </div>
              <h3 className="mt-5 font-display text-xl">{m.title}</h3>
              <p className="mt-2.5 text-sm leading-relaxed text-bone-dim">
                {m.description}
              </p>
              <button className="mt-5 text-sm font-medium text-gold hover:underline">
                Open →
              </button>
            </GlassCard>
          ))}
        </div>
      </div>
    </div>
  );
}

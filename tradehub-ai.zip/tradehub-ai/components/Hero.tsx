"use client";

import { motion } from "framer-motion";
import Link from "next/link";
import { Play, ArrowUpRight } from "lucide-react";

const candles = [
  { h: 34, up: true }, { h: 52, up: true }, { h: 28, up: false }, { h: 61, up: true },
  { h: 40, up: false }, { h: 70, up: true }, { h: 55, up: false }, { h: 82, up: true },
  { h: 46, up: false }, { h: 90, up: true }, { h: 65, up: false }, { h: 100, up: true },
];

export default function Hero() {
  return (
    <section className="noise-overlay relative overflow-hidden">
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse 60% 50% at 50% 0%, rgba(201,162,39,0.14), transparent 70%)",
        }}
      />
      <div className="relative mx-auto max-w-7xl px-6 pb-20 pt-20 lg:px-10 lg:pb-28 lg:pt-28">
        <motion.p
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="eyebrow mx-auto w-fit rounded-full border border-gold/30 bg-gold/5 px-4 py-1.5 text-center text-[11px] uppercase text-gold"
        >
          AI-native trading intelligence
        </motion.p>

        <motion.h1
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
          className="mx-auto mt-8 max-w-4xl text-balance text-center font-display text-5xl leading-[1.05] sm:text-6xl lg:text-7xl"
        >
          Trade Smarter <span className="text-gradient-gold italic">With AI</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.22 }}
          className="mx-auto mt-6 max-w-xl text-center text-lg text-bone-dim"
        >
          AI-powered trading tools for modern traders.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.32 }}
          className="mx-auto mt-10 flex w-fit flex-col items-center gap-4 sm:flex-row"
        >
          <Link
            href="/signup"
            className="group flex items-center gap-2 rounded-full bg-gold-gradient px-7 py-3.5 text-sm font-medium text-ink-900 shadow-gold-glow transition-transform hover:scale-[1.03]"
          >
            Start Free
            <ArrowUpRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
          </Link>
          <button className="group flex items-center gap-2 rounded-full hairline px-7 py-3.5 text-sm font-medium text-bone transition-colors hover:border-gold/40 hover:text-gold">
            <span className="flex h-7 w-7 items-center justify-center rounded-full border border-current">
              <Play className="h-3 w-3 fill-current" />
            </span>
            Watch Demo
          </button>
        </motion.div>

        {/* Signature: live candlestick composition */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.45, ease: [0.22, 1, 0.36, 1] }}
          className="glass relative mx-auto mt-16 flex h-64 max-w-4xl items-end justify-center gap-2.5 overflow-hidden rounded-2xl px-8 pb-8 pt-10 shadow-card sm:h-72"
        >
          <div className="absolute left-6 top-5 font-mono text-[11px] text-bone-dim">
            AAPL · 1D
          </div>
          <div className="absolute right-6 top-5 font-mono text-[11px] text-gold">
            +12.4%
          </div>
          {candles.map((c, i) => (
            <motion.div
              key={i}
              initial={{ height: 0 }}
              animate={{ height: `${c.h}%` }}
              transition={{ duration: 0.7, delay: 0.6 + i * 0.045, ease: [0.22, 1, 0.36, 1] }}
              className={`w-3 rounded-sm sm:w-4 ${
                c.up ? "bg-gold/70" : "bg-bone-dim/25"
              }`}
            />
          ))}
        </motion.div>
      </div>
    </section>
  );
}

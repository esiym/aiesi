"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { LineChart, Loader2 } from "lucide-react";
import { createClient } from "@/lib/supabase/client";

export default function AuthForm({ mode }: { mode: "login" | "signup" }) {
  const router = useRouter();
  const supabase = createClient();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const isLogin = mode === "login";

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const { error } = isLogin
      ? await supabase.auth.signInWithPassword({ email, password })
      : await supabase.auth.signUp({ email, password });

    setLoading(false);

    if (error) {
      setError(error.message);
      return;
    }

    router.push("/dashboard");
  }

  async function handleOAuth() {
    await supabase.auth.signInWithOAuth({
      provider: "google",
      options: { redirectTo: `${window.location.origin}/dashboard` },
    });
  }

  return (
    <section className="noise-overlay relative flex min-h-[calc(100vh-160px)] items-center justify-center px-6 py-16">
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse 50% 40% at 50% 0%, rgba(201,162,39,0.12), transparent 70%)",
        }}
      />
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
        className="glass relative w-full max-w-md rounded-2xl p-8 shadow-card sm:p-10"
      >
        <Link href="/" className="flex items-center justify-center gap-2.5">
          <span className="flex h-8 w-8 items-center justify-center rounded-full border border-gold/40 bg-gold/5">
            <LineChart className="h-4 w-4 text-gold" strokeWidth={1.75} />
          </span>
          <span className="font-display text-lg">
            TradeHub <span className="text-gradient-gold italic">AI</span>
          </span>
        </Link>

        <h1 className="mt-8 text-center font-display text-2xl">
          {isLogin ? "Welcome back" : "Create your account"}
        </h1>
        <p className="mt-2 text-center text-sm text-bone-dim">
          {isLogin
            ? "Log in to access your dashboard."
            : "Start free — no card required."}
        </p>

        <form onSubmit={handleSubmit} className="mt-8 space-y-4">
          <div>
            <label htmlFor="email" className="text-xs text-bone-dim">
              Email
            </label>
            <input
              id="email"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              className="mt-1.5 w-full rounded-lg hairline bg-ink-800 px-4 py-3 text-sm text-bone outline-none transition-colors focus:border-gold/50"
            />
          </div>

          <div>
            <label htmlFor="password" className="text-xs text-bone-dim">
              Password
            </label>
            <input
              id="password"
              type="password"
              required
              minLength={8}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="mt-1.5 w-full rounded-lg hairline bg-ink-800 px-4 py-3 text-sm text-bone outline-none transition-colors focus:border-gold/50"
            />
          </div>

          {error && (
            <p className="rounded-lg border border-red-500/30 bg-red-500/10 px-4 py-2.5 text-xs text-red-300">
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={loading}
            className="flex w-full items-center justify-center gap-2 rounded-full bg-gold-gradient px-6 py-3 text-sm font-medium text-ink-900 shadow-gold-glow transition-transform hover:scale-[1.01] disabled:opacity-60"
          >
            {loading && <Loader2 className="h-4 w-4 animate-spin" />}
            {isLogin ? "Log in" : "Create account"}
          </button>
        </form>

        <div className="my-6 flex items-center gap-3">
          <div className="h-px flex-1 bg-white/[0.08]" />
          <span className="text-xs text-bone-dim">or</span>
          <div className="h-px flex-1 bg-white/[0.08]" />
        </div>

        <button
          onClick={handleOAuth}
          className="w-full rounded-full hairline px-6 py-3 text-sm font-medium text-bone transition-colors hover:border-gold/40 hover:text-gold"
        >
          Continue with Google
        </button>

        <p className="mt-8 text-center text-sm text-bone-dim">
          {isLogin ? "Don't have an account? " : "Already have an account? "}
          <Link
            href={isLogin ? "/signup" : "/login"}
            className="font-medium text-gold hover:underline"
          >
            {isLogin ? "Sign up" : "Log in"}
          </Link>
        </p>
      </motion.div>
    </section>
  );
}

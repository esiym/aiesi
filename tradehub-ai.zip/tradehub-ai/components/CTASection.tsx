"use client";

import { motion } from "framer-motion";
import Link from "next/link";
import { ArrowUpRight } from "lucide-react";

export default function CTASection() {
  return (
    <section className="border-t border-white/[0.06] py-24 lg:py-32">
      <div className="mx-auto max-w-4xl px-6 text-center lg:px-10">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
          className="glass-gold rounded-3xl px-8 py-16 shadow-gold-glow sm:px-16"
        >
          <h2 className="font-display text-3xl leading-tight sm:text-4xl">
            Trade with an <span className="text-gradient-gold italic">edge</span>,
            not a hunch.
          </h2>
          <p className="mx-auto mt-4 max-w-md text-bone-dim">
            Join TradeHub AI free today. Upgrade whenever your strategy is
            ready to scale.
          </p>
          <Link
            href="/signup"
            className="group mt-8 inline-flex items-center gap-2 rounded-full bg-gold-gradient px-7 py-3.5 text-sm font-medium text-ink-900 transition-transform hover:scale-[1.03]"
          >
            Start Free
            <ArrowUpRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
          </Link>
        </motion.div>
      </div>
    </section>
  );
}
